.. cmake-module:: ../../Modules/CheckSymbolExists.cmake
